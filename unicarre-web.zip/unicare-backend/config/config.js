module.exports = {
  development: {
    username: "root",
    password: "passionate4589@M5",
    database: "database_development",
    host: "127.0.0.1",
    dialect: "mysql",
  },
  test: {
    username: "root",
    password: "passionate4589@M5",
    database: "database_test",
    host: "127.0.0.1",
    dialect: "mysql",
  },
  production: {
    username: "root",
    password: "passionate4589@M5",
    database: "database_production",
    host: "127.0.0.1",
    dialect: "mysql",
  },
};
